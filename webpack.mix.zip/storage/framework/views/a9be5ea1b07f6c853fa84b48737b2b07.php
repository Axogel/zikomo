<?php $__env->startSection('title', 'Inicio'); ?>

<?php $__env->startSection('content'); ?>
    <div class="grid grid-cols-5 gap-4">
        <div class="bg-zinc-600 rounded-lg shadow p-4 flex flex-col items-center text-white">
            <img src="book-icon.png" class="w-8 h-8 mb-2" />
            <span>Ver Todos Los Libros</span>
        </div>
        <div class="bg-zinc-600 rounded-lg shadow p-4 flex flex-col items-center text-white">
            <img src="ledger-icon.png" class="w-8 h-8 mb-2" />
            <span>Crear Un Libro Mayor</span>
        </div>
        <div class="bg-zinc-600 rounded-lg shadow p-4 flex flex-col items-center text-white">
            <img src="diary-icon.png" class="w-8 h-8 mb-2" />
            <span>Ver Libros Diarios</span>
        </div>
        <div class="bg-zinc-600 rounded-lg shadow p-4 flex flex-col items-center text-white">
            <img src="new-diary-icon.png" class="w-8 h-8 mb-2" />
            <span>Crear Un Libro Diario</span>
        </div>
        <div class="bg-zinc-600 rounded-lg shadow p-4 flex flex-col items-center text-white">
            <img src="tie-icon.png" class="w-8 h-8 mb-2" />
            <span>Ingresar Producto</span>
        </div>
        <div class="bg-zinc-600 rounded-lg shadow p-4 flex flex-col items-center text-white">
            <img src="store-icon.png" class="w-8 h-8 mb-2" />
            <span>Ver Todos Los Productos</span>
        </div>
        <div class="bg-zinc-600 rounded-lg shadow p-4 flex flex-col items-center text-white">
            <img src="client-icon.png" class="w-8 h-8 mb-2" />
            <span>Ver Todos Los Clientes</span>
        </div>
        <div class="bg-zinc-600 rounded-lg shadow p-4 flex flex-col items-center text-white">
            <img src="new-client-icon.png" class="w-8 h-8 mb-2" />
            <span>Registrar Un Cliente En El Sistema</span>
        </div>
        <div class="bg-zinc-600 rounded-lg shadow p-4 flex flex-col items-center text-white">
            <img src="order-icon.png" class="w-8 h-8 mb-2" />
            <span>Ver Todas Las Ordenes De Entrega</span>
        </div>
        <div class="bg-zinc-600 rounded-lg shadow p-4 flex flex-col items-center text-white">
            <img src="new-order-icon.png" class="w-8 h-8 mb-2" />
            <span>Crear Una Orden De Entrega</span>
        </div>
        <div class="bg-zinc-600 rounded-lg shadow p-4 flex flex-col items-center text-white">
            <img src="invoice-icon.png" class="w-8 h-8 mb-2" />
            <span>Ingresar Datos De Una Nueva Factura</span>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SoftwareDevelopment\Compiladores\laragon\www\angel\resources\views/dashboard.blade.php ENDPATH**/ ?>