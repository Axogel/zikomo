<?php $__env->startSection('title', 'Nuevo Cliente'); ?>

<?php $__env->startSection('content'); ?>
        <div class="bg-gray-100 p-6 rounded-lg shadow-lg ">
          <h2 class="text-2xl font-bold mb-4">Crear Clientes</h2>
          <form>
            <div class="mb-4">
              <label class="block text-gray-700 font-bold mb-2" for="nombre">Nombre</label>
              <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" id="nombre" type="text" placeholder="Ingrese su nombre">
            </div>

            <div class="mb-4">
              <label class="block text-gray-700 font-bold mb-2" for="apellido">Apellido</label>
              <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" id="apellido" type="text" placeholder="Ingrese su apellido">
            </div>

            <div class="mb-4">
              <label class="block text-gray-700 font-bold mb-2" for="direccion">Direccion</label>
              <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" id="direccion" type="text" placeholder="Ingrese su dirección">
            </div>

            <div class="mb-4">
              <label class="block text-gray-700 font-bold mb-2" for="cedula">Cedula de Identidad</label>
              <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" id="cedula" type="text" placeholder="Ingrese su cédula de identidad">
            </div>

            <div class="mb-4">
              <label class="block text-gray-700 font-bold mb-2" for="email">Correo del cliente</label>
              <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" id="email" type="email" placeholder="Ingrese su correo electrónico">
            </div>

            <div class="mb-4">
              <label class="block text-gray-700 font-bold mb-2" for="fecha">Fecha De Nacimiento</label>
              <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" id="fecha" type="text" placeholder="dd/mm/aaaa">
            </div>

            <div class="mb-6">
              <label class="block text-gray-700 font-bold mb-2" for="telefono">Telefono</label>
              <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" id="telefono" type="tel" placeholder="Ingrese su número de teléfono">
            </div>

            <div class="flex items-center justify-between">
              <button class="bg-zinc-600 hover:bg-zinc-500 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" type="button">
                Crear
              </button>
              <button class="bg-zinc-600 hover:bg-zinc-500 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" type="button">
                Cancelar
              </button>
            </div>
          </form>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SoftwareDevelopment\Compiladores\laragon\www\angel\resources\views/clients/create.blade.php ENDPATH**/ ?>